﻿namespace Admin.Models
{
    public class CityDistributionDto
    {
        public string City { get; set; }
        public int UserCount { get; set; }
        public int ShopkeeperCount { get; set; }
    }
}
